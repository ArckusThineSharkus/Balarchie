SMODS.Consumable {
    key = 'acellus',
    set = 'Spectral',
    pos = { x = 0, y = 0 },
    config = { extra = {
        double_limit = 40
    } },
    loc_txt = {
        name = 'Acellus',
        text = {
        [1] = 'Use 3 cards To make them {X:chips,C:white}bored{} and gamble there life\'s away to you (you get 40$)'
    }
    },
    cost = 3,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted == 3 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('timpani')
                    used_card:juice_up(0.3, 0.5)
                    local double_amount = math.min(G.GAME.dollars, 40)
                    ease_dollars(double_amount, true)
                    return true
                end
            }))
            delay(0.6)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted == 3)
    end
}