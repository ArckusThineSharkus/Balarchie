SMODS.Consumable {
    key = 'kingarchie',
    set = 'Tarot',
    pos = { x = 2, y = 0 },
    loc_txt = {
        name = 'KING ARCHIE',
        text = {
        [1] = 'Can Convert 2 Playing Cards Into WARFORGE {C:enhanced}Enhancements{}'
    }
    },
    cost = 3,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    can_use = function(self, card)
        return true
    end
}