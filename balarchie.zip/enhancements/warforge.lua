SMODS.Enhancement {
    key = 'warforge',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            x_mult = 17,
            x_mult = 9,
            x_mult = 5
        }
    },
    loc_txt = {
        name = 'WARFORGE',
        text = {
        [1] = 'When a card is played with the {C:enhanced}Enhancement{}',
        [2] = 'the more big the blind the more {X:red,C:white}Mult{}',
        [3] = '',
        [4] = '',
        [5] = ''
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = true,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = true,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 5,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play and G.GAME.blind.boss then
            return { x_mult = card.ability.extra.x_mult }
        end
        if context.main_scoring and context.cardarea == G.play and G.GAME.blind:get_type() == 'Big' then
            return { x_mult = card.ability.extra.x_mult }
        end
        if context.main_scoring and context.cardarea == G.play and G.GAME.blind:get_type() == 'Small' then
            return { x_mult = card.ability.extra.x_mult }
        end
    end
}