SMODS.Enhancement {
    key = 'cavtie',
    pos = { x = 1, y = 0 },
    config = {
        h_chips = 5
    },
    loc_txt = {
        name = 'Cavtie',
        text = {
        [1] = 'Gives you Just a BIT of {X:planet,C:white}Chips{} But Waterpik will handle it'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 5
}