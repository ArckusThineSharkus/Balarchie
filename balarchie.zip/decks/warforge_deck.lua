SMODS.Back {
    key = 'warforge_deck',
    pos = { x = 1, y = 0 },
    config = {
},
    loc_txt = {
        name = 'Warforge deck',
        text = {
            [1] = 'Can Only Spawn {C:dark_edition}WARFORGE{} Playing Cards'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
     apply = function(self, back)
            G.E_MANAGER:add_event(Event({
                    func = function()
                    for k, v in pairs(G.playing_cards) do
                        v:set_ability(G.P_CENTERS['m_balarch_warforge'])
                    end
                    return true
                end
            }))
    end
}