SMODS.Back {
    key = 'archie_and_shity_dad_deck',
    pos = { x = 0, y = 0 },
    config = {
},
    loc_txt = {
        name = 'Archie And SHITY Dad deck',
        text = {
            [1] = 'When A Boss {X:blue,C:white}Blind{}',
            [2] = 'Is over Fred will sue you and take {X:money,C:white}3${}'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    calculate = function(self, card, context)
        if context.end_of_round and context.main_eval and G.GAME.blind.boss then
            ease_dollars(-3)
        end
  end,
  
}