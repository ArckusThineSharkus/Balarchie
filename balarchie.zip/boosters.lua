SMODS.Booster {
    key = 'warforge',
    loc_txt = {
        name = "WARFORGE BOOSTER PACK",
        text = {
            [1] = 'not done cus i dont have dogs in it'
        },
        group_name = "WARFORGE BOOSTER PACK"
    },
    config = { extra = 3, choose = 1 },
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local selected_index = pseudorandom('balarch_warforge_card', 1, 2)
        if selected_index == 1 then
            return {
            set = "balarch_warforge",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "balarch_warforge"
            }
        elseif selected_index == 2 then
            return {
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "balarch_warforge"
            }
        end
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'super_duper_warforge_pack',
    loc_txt = {
        name = "SUPER DUPER WARFORGE PACK",
        text = {
            [1] = '(not done cuz i dont have dogs ): Choose 2 Out of 5 Card'
        },
        group_name = "balarch_boosters"
    },
    config = { extra = 5, choose = 2 },
    atlas = "CustomBoosters",
    pos = { x = 1, y = 0 },
    group_key = "balarch_boosters",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
            set = "Joker",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}
