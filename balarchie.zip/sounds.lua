SMODS.Sound{
    key="heyrichard",
    path="heyrichard.ogg",
    pitch=0.7,
    volume=0.6,
}