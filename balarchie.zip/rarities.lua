SMODS.Rarity {
    key = "richard",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.01,
    badge_colour = HEX('000509'),
    loc_txt = {
        name = "Richard"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}