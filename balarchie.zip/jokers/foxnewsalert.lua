SMODS.Joker{ --FOX NEWS ALERT
    key = "foxnewsalert",
    config = {
        extra = {
            chips = 5,
            mult = 6,
            dollars = 1
        }
    },
    loc_txt = {
        ['name'] = 'FOX NEWS ALERT',
        ['text'] = {
            [1] = '(Its says propoganda so it not op)',
            [2] = 'GIVES{X:red,C:white}677 MILLONMULT{}',
            [3] = '{X:blue,C:white}DONALAND TRUMP X CHIPS DRUNGS{}',
            [4] = '{X:attention,C:white}MEXICANS ARE BAD HAHAHHA{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balarch_balarch_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = card.ability.extra.chips,
                message = "DONALD TRUMP ",
                extra = {
                mult = card.ability.extra.mult,
                message = "677 MILLON BILLON TRANSHOPIBIC MULT",
                extra = {
                dollars = card.ability.extra.dollars,
                message = "MEXICANS BAD BAD DRUNGS BAD",
                colour = G.C.MONEY
            }
        }
    }
end
end
}