SMODS.Joker{ --MONEY?!?!?!
    key = "money",
    config = {
        extra = {
            odds = 10,
            dollars = 1
        }
    },
    loc_txt = {
        ['name'] = 'MONEY?!?!?!',
        ['text'] = {
            [1] = 'Has A {X:green,C:white}1/10{} Chane of giveing {X:money,C:white}1${}',
            [2] = 'Per Card Played'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balarch_balarch_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_112a8472', 1, card.ability.extra.odds, 'j_balarch_money', false) then
                        SMODS.calculate_effect({dollars = card.ability.extra.dollars}, card)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "MONEY!!!!!!?!?!?", colour = G.C.MONEY})
                    end
                end
            end
        end
}