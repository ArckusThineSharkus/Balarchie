SMODS.Joker{ --Bagle Bites
    key = "j_balarch_baglebites",
    config = {
        extra = {
            levels = 2,
            odds = 5,
            levels2 = 5
        }
    },
    loc_txt = {
        ['name'] = 'Bagle Bites',
        ['text'] = {
            [1] = 'When a {C:uncommon}Hand{} is Played it will level up hand by 2',
            [2] = 'there is a {C:uncommon}1 in 5 chance{} of leveling it by 5'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balarch_warforge"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                local target_hand = (context.scoring_name or "High Card")
                return {
                    level_up = card.ability.extra.levels,
                    level_up_hand = target_hand,
                    message = localize('k_level_up_ex')
                    ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_d32aed44', 1, card.ability.extra.odds, 'j_balarch_j_balarch_baglebites', false) then
                            local target_hand2 = (context.scoring_name or "High Card")
                                SMODS.calculate_effect({level_up = card.ability.extra.levels2,
                            level_up_hand = target_hand2}, card)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_level_up_ex'), colour = G.C.RED})
                        end
                        return true
                        end
                    }
                end
            end
        end
}