SMODS.Joker{ --GTA GUY
    key = "gtaguy",
    config = {
        extra = {
            dollars = 1,
            Xmult = 3,
            odds = 20
        }
    },
    loc_txt = {
        ['name'] = 'GTA GUY',
        ['text'] = {
            [1] = 'This Card Will take {X:money,C:white}1${} and has a {C:green}1 In 20{} Chance',
            [2] = 'Of Death But you get X3 {X:mult,C:white}Mult{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balarch_balarch_jokers"] = true },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' 
          or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                return {
                    dollars = -card.ability.extra.dollars,
                    extra = {
                    Xmult = card.ability.extra.Xmult
                }
                ,
                func = function()
                    if SMODS.pseudorandom_probability(card, 'group_0_e1ca21ab', 1, card.ability.extra.odds, 'j_balarch_gtaguy', false) then
                            SMODS.calculate_effect({func = function()
                                
                                G.E_MANAGER:add_event(Event({
                                trigger = 'after',
                                delay = 0.5,
                                func = function()
                                    if G.STAGE == G.STAGES.RUN then 
                                        G.STATE = G.STATES.GAME_OVER
                                        G.STATE_COMPLETE = false
                                    end
                                end
                            }))
                            
                            return true
                            end}, card)
                        end
                        return true
                        end
                    }
                end
            end
        end
}