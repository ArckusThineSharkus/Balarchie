SMODS.Joker{ --ARCHIE VS DAD
    key = "archievsdad",
    config = {
        extra = {
            odds = 2,
            chips = 67,
            dollars = 3
        }
    },
    loc_txt = {
        ['name'] = 'ARCHIE VS DAD',
        ['text'] = {
            [1] = 'Has A {X:green,C:white}50/50{} Chance To give {X:chips,C:white}67{} Chips',
            [2] = 'OR Remove {X:money,C:white}3${}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balarch_balarch_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_d4b654f3', 1, card.ability.extra.odds, 'j_balarch_archievsdad', false) then
                        SMODS.calculate_effect({chips = card.ability.extra.chips}, card)
                    end
                    if SMODS.pseudorandom_probability(card, 'group_1_f1593673', 1, card.ability.extra.odds, 'j_balarch_archievsdad', false) then
                            SMODS.calculate_effect({dollars = -card.ability.extra.dollars}, card)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "haha fuck ur mom archie", colour = G.C.MONEY})
                        end
                    end
                end
            end
}