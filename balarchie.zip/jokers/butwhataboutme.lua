SMODS.Joker{ --But What About ME
    key = "butwhataboutme",
    config = {
        extra = {
            chips = 10,
            mult = 1,
            chips2 = 10,
            mult2 = 1,
            chips3 = 10,
            mult3 = 1,
            chips4 = 10,
            mult4 = 1,
            chips5 = 10,
            mult5 = 1,
            chips6 = 10,
            mult6 = 1,
            chips7 = 10,
            mult7 = 1,
            chips8 = 10,
            mult8 = 1,
            chips9 = 10,
            mult9 = 1,
            chips10 = 10,
            mult10 = 1,
            chips11 = 10,
            mult11 = 1
        }
    },
    loc_txt = {
        ['name'] = 'But What About ME',
        ['text'] = {
            [1] = 'All Hand Plays are buffed By {X:mult,C:white}1{} Mult and {X:chips,C:white}1{} Chip',
            [2] = 'But NOT for Flushes'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balarch_balarch_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if next(context.poker_hands["High Card"]) then
                return {
                    chips = card.ability.extra.chips,
                    extra = {
                    mult = card.ability.extra.mult
                }
            }
        elseif next(context.poker_hands["Pair"]) then
            return {
                chips = card.ability.extra.chips2,
                extra = {
                mult = card.ability.extra.mult2
            }
        }
    elseif next(context.poker_hands["Two Pair"]) then
        return {
            chips = card.ability.extra.chips3,
            extra = {
            mult = card.ability.extra.mult3
        }
    }
elseif next(context.poker_hands["Three of a Kind"]) then
    return {
        chips = card.ability.extra.chips4,
        extra = {
        mult = card.ability.extra.mult4
    }
}
elseif next(context.poker_hands["Straight"]) then
return {
    chips = card.ability.extra.chips5,
    extra = {
    mult = card.ability.extra.mult5
}
}
elseif next(context.poker_hands["Full House"]) then
return {
chips = card.ability.extra.chips6,
extra = {
mult = card.ability.extra.mult6
}
}
elseif next(context.poker_hands["Four of a Kind"]) then
return {
chips = card.ability.extra.chips7,
extra = {
mult = card.ability.extra.mult7
}
}
elseif next(context.poker_hands["Five of a Kind"]) then
return {
chips = card.ability.extra.chips8,
extra = {
mult = card.ability.extra.mult8
}
}
elseif next(context.poker_hands["Straight Flush"]) then
return {
chips = card.ability.extra.chips9,
extra = {
mult = card.ability.extra.mult9
}
}
elseif next(context.poker_hands["Flush House"]) then
return {
chips = card.ability.extra.chips10,
extra = {
mult = card.ability.extra.mult10
}
}
elseif next(context.poker_hands["Flush Five"]) then
return {
chips = card.ability.extra.chips11,
extra = {
mult = card.ability.extra.mult11
}
}
end
end
end
}