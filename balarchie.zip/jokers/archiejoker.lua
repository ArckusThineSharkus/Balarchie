SMODS.Joker{ --Archiejoker
    key = "archiejoker",
    config = {
        extra = {
            chips = 67,
            heyrichard = 0
        }
    },
    loc_txt = {
        ['name'] = 'Archiejoker',
        ['text'] = {
            [1] = 'Gives {C:dark_edition}67{} {X:blue,C:white}Chips{} And says Hey Richard!'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balarch_warforge"] = true },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' 
          or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            G.E_MANAGER:add_event(Event({
            func = function()
                play_sound("heyrichard")
                
                return true
                end,
            }))
            return {
                chips = card.ability.extra.chips,
                extra = {
                message = "HEY RICHARD!",
                colour = G.C.WHITE
            }
        }
    end
end
}