SMODS.Joker{ --Waterpik
    key = "waterpik",
    config = {
        extra = {
            chips = 20,
            chips2 = 40,
            chips3 = 60,
            chips4 = 80,
            gunshot = 0
        }
    },
    loc_txt = {
        ['name'] = 'Waterpik',
        ['text'] = {
            [1] = 'If there is a cavitie card in hand it will shoot it and give {C:blue}20 chips{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balarch_warforge"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                local count = 0
                for _, playing_card in pairs(context.scoring_hand or {}) do
                    if SMODS.get_enhancements(playing_card)["undefined"] == true then
                        count = count + 1
                    end
                end
                return count == 1
                end)() then
                    G.E_MANAGER:add_event(Event({
                    func = function()
                        play_sound("gunshot")
                            SMODS.calculate_effect({message = "BOOM!"}, card)
                            return true
                            end,
                        }))
                        return {
                            chips = card.ability.extra.chips
                        }
                    elseif (function()
                        local count = 0
                        for _, playing_card in pairs(context.scoring_hand or {}) do
                            if SMODS.get_enhancements(playing_card)["m_balarch_cavtie"] == true then
                                count = count + 1
                            end
                        end
                        return count == 2
                        end)() then
                            return {
                                chips = card.ability.extra.chips2
                            }
                        elseif (function()
                            local count = 0
                            for _, playing_card in pairs(context.scoring_hand or {}) do
                                if SMODS.get_enhancements(playing_card)["m_balarch_cavtie"] == true then
                                    count = count + 1
                                end
                            end
                            return count == 3
                            end)() then
                                return {
                                    chips = card.ability.extra.chips3
                                }
                            elseif (function()
                                local count = 0
                                for _, playing_card in pairs(context.scoring_hand or {}) do
                                    if SMODS.get_enhancements(playing_card)["undefined"] == true then
                                        count = count + 1
                                    end
                                end
                                return count == 5
                                end)() then
                                    return {
                                        chips = card.ability.extra.chips4
                                    }
                                end
                            end
                        end
}

local check_for_buy_space_ref = G.FUNCS.check_for_buy_space
G.FUNCS.check_for_buy_space = function(card)
    if card.config.center.key == "j_balarch_waterpik" then -- ignore slot limit when bought
        return true
    end
    return check_for_buy_space_ref(card)
end

local can_select_card_ref = G.FUNCS.can_select_card
G.FUNCS.can_select_card = function(e)
	if e.config.ref_table.config.center.key == "j_balarch_waterpik" then
		e.config.colour = G.C.GREEN
		e.config.button = "use_card"
	else
		can_select_card_ref(e)
	end
end