SMODS.Joker{ --JELLY
    key = "jelly",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'JELLY',
        ['text'] = {
            [1] = 'She Loves Howling That For Sure'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["balarch_balarch_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.discard  then
            return {
                message = "AROOOOO"
            }
        end
    end
}